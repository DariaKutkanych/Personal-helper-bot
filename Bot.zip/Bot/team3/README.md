# Personal-helper-bot
chat bot that helps to work with personal data
