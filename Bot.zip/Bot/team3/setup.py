from setuptools import setup, find_packages, find_namespace_packages

setup(
    name='team3',
    version='1',
    description='Very useful code',
    author='Flying Circus',
    packages=find_namespace_packages(),
    include_package_data=True,
    install_requires=['prettytable'],
    entry_points={'console_scripts': ['bobryhelper = team3.main:main']},
)